package com.nfraz007.lovely.calculator;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * Created by nfraz007 on 06-07-2015.
 */
public class MyPreference extends PreferenceActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.mypreference);
    }
}
