package com.nfraz007.lovely.calculator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Vibrator;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.Math;


public class MainActivity extends Activity implements View.OnClickListener {

    Button bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8,bt9,bt0,btdel,btac,btmul,btdiv,btplus,btmin,btpoint,btchange,btmod,bteq;
    Button btasin,btacos,btatan,btexp,btexp10,btsin,btcos,bttan,btln,btlog,btinverse,btsqrt,btsq,btxroot,btpower;
    Button btfact,btpi,bte,btcbroot,btcube,btdeg;
    TextView tv,tvopr,tvmain,tvpower,tvpower10;
    String scr="",opr,oprPrev;
    double num1,num2,ans;
    int clear=0, oprCount=0, pointCount=0, powerValue=0,tap;
    boolean start=true, degree=true, musicValue, vibrationValue;
    SoundPool sp;
    SharedPreferences myPref;
    Vibrator vib;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        declare();
        init();
        sound();
    }

    private void declare() {
        bt1=(Button)findViewById(R.id.xbt1);
        bt2=(Button)findViewById(R.id.xbt2);
        bt3=(Button)findViewById(R.id.xbt3);
        bt4=(Button)findViewById(R.id.xbt4);
        bt5=(Button)findViewById(R.id.xbt5);
        bt6=(Button)findViewById(R.id.xbt6);
        bt7=(Button)findViewById(R.id.xbt7);
        bt8=(Button)findViewById(R.id.xbt8);
        bt9=(Button)findViewById(R.id.xbt9);
        bt0=(Button)findViewById(R.id.xbt0);
        btdel=(Button)findViewById(R.id.xbtdel);
        btac=(Button)findViewById(R.id.xbtac);
        btmul=(Button)findViewById(R.id.xbtmul);
        btdiv=(Button)findViewById(R.id.xbtdiv);
        btplus=(Button)findViewById(R.id.xbtplus);
        btmin=(Button)findViewById(R.id.xbtmin);
        btmod=(Button)findViewById(R.id.xbtmod);
        btchange=(Button)findViewById(R.id.xbtchange);
        bteq=(Button)findViewById(R.id.xbteq);
        btpoint=(Button)findViewById(R.id.xbtpoint);

        btasin=(Button)findViewById(R.id.xbtasin);
        btacos=(Button)findViewById(R.id.xbtacos);
        btatan=(Button)findViewById(R.id.xbtatan);
        btexp=(Button)findViewById(R.id.xbtexp);
        btexp10=(Button)findViewById(R.id.xbtexp10);
        btsin=(Button)findViewById(R.id.xbtsin);
        btcos=(Button)findViewById(R.id.xbtcos);
        bttan=(Button)findViewById(R.id.xbttan);
        btln=(Button)findViewById(R.id.xbtln);
        btlog=(Button)findViewById(R.id.xbtlog);
        btinverse=(Button)findViewById(R.id.xbtinverse);
        btsqrt=(Button)findViewById(R.id.xbtsqrt);
        btsq=(Button)findViewById(R.id.xbtsq);
        btxroot=(Button)findViewById(R.id.xbtxroot);
        btpower=(Button)findViewById(R.id.xbtpower);
        btfact=(Button)findViewById(R.id.xbtfact);
        btpi=(Button)findViewById(R.id.xbtpi);
        bte=(Button)findViewById(R.id.xbte);
        btcbroot=(Button)findViewById(R.id.xbtcbroot);
        btcube=(Button)findViewById(R.id.xbtcube);

        btdeg=(Button)findViewById(R.id.xbtdeg);

        tv=(TextView)findViewById(R.id.xtv);
        tvopr=(TextView)findViewById(R.id.xtvopr);
        tvmain=(TextView)findViewById(R.id.xtvmain);
        tvpower=(TextView)findViewById(R.id.xtvpower);
        tvpower10=(TextView)findViewById(R.id.xtvpower10);
    }

    private void init() {

        bt1.setOnClickListener(this);
        bt2.setOnClickListener(this);
        bt3.setOnClickListener(this);
        bt4.setOnClickListener(this);
        bt5.setOnClickListener(this);
        bt6.setOnClickListener(this);
        bt7.setOnClickListener(this);
        bt8.setOnClickListener(this);
        bt9.setOnClickListener(this);
        bt0.setOnClickListener(this);

        btdel.setOnClickListener(this);
        btac.setOnClickListener(this);
        btmul.setOnClickListener(this);
        btdiv.setOnClickListener(this);
        btplus.setOnClickListener(this);
        btmin.setOnClickListener(this);
        btmod.setOnClickListener(this);
        btchange.setOnClickListener(this);
        bteq.setOnClickListener(this);
        btpoint.setOnClickListener(this);

        btasin.setOnClickListener(this);
        btacos.setOnClickListener(this);
        btatan.setOnClickListener(this);
        btexp.setOnClickListener(this);
        btexp10.setOnClickListener(this);
        btsin.setOnClickListener(this);
        btcos.setOnClickListener(this);
        bttan.setOnClickListener(this);
        btln.setOnClickListener(this);
        btlog.setOnClickListener(this);
        btinverse.setOnClickListener(this);
        btsqrt.setOnClickListener(this);
        btsq.setOnClickListener(this);
        btxroot.setOnClickListener(this);
        btpower.setOnClickListener(this);
        btfact.setOnClickListener(this);
        btpi.setOnClickListener(this);
        bte.setOnClickListener(this);
        btcbroot.setOnClickListener(this);
        btcube.setOnClickListener(this);

        btdeg.setOnClickListener(this);
    }

    //for sound
    private void sound() {

        myPref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        sp= new SoundPool(5, AudioManager.STREAM_MUSIC,0);
        tap=sp.load(this, R.raw.tapsound, 1);
        //for vibration
        vib=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        setTheme(R.style.Platform_AppCompat);

        MenuItem menu1=menu.add(0,0,0,"Help");
        MenuItem menu2=menu.add(0,1,1,"About");
        MenuItem menu3=menu.add(0,2,2,"Setting");
        MenuItem menu4=menu.add(0, 3, 3, "Exit");
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case 0: startActivity(new Intent(this,Help.class)); break;
            case 1: startActivity(new Intent(this,About.class)); break;
            case 2: startActivity(new Intent(this,MyPreference.class)); break;
            case 3: finish(); break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        musicValue=myPref.getBoolean("soundValue",true);
        if(musicValue) sp.play(tap, 1, 1, 0, 0, 1);
        vibrationValue=myPref.getBoolean("vibValue",true);
        if(vibrationValue) vib.vibrate(50);

        switch (v.getId())
        {
            case R.id.xbt1 : number("1"); break;
            case R.id.xbt2 : number("2"); break;
            case R.id.xbt3 : number("3"); break;
            case R.id.xbt4 : number("4"); break;
            case R.id.xbt5 : number("5"); break;
            case R.id.xbt6 : number("6"); break;
            case R.id.xbt7 : number("7"); break;
            case R.id.xbt8 : number("8"); break;
            case R.id.xbt9 : number("9"); break;
            case R.id.xbt0 : number("0"); break;

            case R.id.xbtdel : delete(); break;
            case R.id.xbtac : ac(); break;
            case R.id.xbtmul : operation("*"); break;
            case R.id.xbtdiv : operation("/"); break;
            case R.id.xbtplus : operation("+"); break;
            case R.id.xbtmin : operation("-"); break;
            case R.id.xbtpoint : point(); break;
            case R.id.xbtchange : change(); break;
            case R.id.xbtmod : mod(); break;
            case R.id.xbteq : equal(); break;

            //function...
            case R.id.xbtasin: function(1); break;
            case R.id.xbtacos: function(2); break;
            case R.id.xbtatan: function(3); break;
            case R.id.xbtexp: function(4); break;
            case R.id.xbtexp10: function(5); break;
            case R.id.xbtsin: function(6); break;
            case R.id.xbtcos: function(7); break;
            case R.id.xbttan: function(8); break;
            case R.id.xbtln: function(9); break;
            case R.id.xbtlog: function(10); break;
            case R.id.xbtinverse: function(11); break;
            case R.id.xbtsqrt: function(12); break;
            case R.id.xbtsq: function(13); break;
            case R.id.xbtxroot: function(14); break;
            case R.id.xbtpower: function(15); break;
            case R.id.xbtfact: function(16); break;
            case R.id.xbtpi: function(17); break;
            case R.id.xbte: function(18); break;
            case R.id.xbtcbroot: function(19); break;
            case R.id.xbtcube: function(20); break;

            case R.id.xbtdeg: degreefunc(); break;

        }
        //when print infinity
        if(tv.getText().toString().equals("Infinity"))
        {
            Toast.makeText(this,"out of range",Toast.LENGTH_LONG).show();
            ac();
        }
    }

    private void function(int i) {
        Double x;
        switch (i)
        {
            //for asin
            case 1: x=Double.parseDouble(tv.getText().toString());
                    if(degree==true) ans=Math.toDegrees(Math.asin(x));
                    else ans=Math.asin(x);
                    tv.setText(Double.toString(ans)); break;
            //for acos
            case 2: x=Double.parseDouble(tv.getText().toString());
                    if(degree==true) ans=Math.toDegrees(Math.acos(x));
                    else ans=Math.acos(x);
                    tv.setText(Double.toString(ans)); break;
            //for atan
            case 3: x=Double.parseDouble(tv.getText().toString());
                    if(degree==true) ans=Math.toDegrees(Math.atan(x));
                    else ans=Math.atan(x);
                    tv.setText(Double.toString(ans)); break;
            //for exp
            case 4: x=Double.parseDouble(tv.getText().toString());
                    ans=Math.exp(x);
                    tv.setText(Double.toString(ans)); break;
            //for exp10
            case 5: x=Double.parseDouble(tv.getText().toString());
                    ans=Math.pow(10,x);
                    tv.setText(Double.toString(ans)); break;
            //for sin
            case 6: x=Double.parseDouble(tv.getText().toString());
                    if(degree==true) ans=Math.sin(Math.toRadians(x));
                    else ans=Math.sin(x);
                    tv.setText(Double.toString(ans)); break;
            //for cos
            case 7: x=Double.parseDouble(tv.getText().toString());
                    if(degree==true) ans=Math.cos(Math.toRadians(x));
                    else ans=Math.cos(x);
                    tv.setText(Double.toString(ans)); break;
            //for tan
            case 8: x=Double.parseDouble(tv.getText().toString());
                    if(degree==true) ans=Math.tan(Math.toRadians(x));
                    else ans=Math.tan(x);
                    tv.setText(Double.toString(ans)); break;
            //for ln
            case 9: x=Double.parseDouble(tv.getText().toString());
                    ans=Math.log(x);
                    tv.setText(Double.toString(ans)); break;
            //for log
            case 10: x=Double.parseDouble(tv.getText().toString());
                    ans=Math.log10(x);
                    tv.setText(Double.toString(ans)); break;
            //for Inverse
            case 11: x=Double.parseDouble(tv.getText().toString());
                    ans=Math.pow(x, -1);
                    tv.setText(Double.toString(ans)); break;
            //for Square root
            case 12: x = Double.parseDouble(tv.getText().toString());
                    ans=Math.sqrt(x);
                    tv.setText(Double.toString(ans)); break;
            //for square
            case 13: x = Double.parseDouble(tv.getText().toString());
                    ans=Math.pow(x, 2);
                    tv.setText(Double.toString(ans)); break;
            //for x root
            case 14: x = Double.parseDouble(tv.getText().toString());
                    ans=x; powerValue=1; break;
            //for power
            case 15: x = Double.parseDouble(tv.getText().toString());
                    ans=x; powerValue=2; break;
            //for fact
            case 16: fact(); break;
            //for pi
            case 17: ans=3.141592654;
                    tv.setText(Double.toString(ans)); break;
            //for e
            case 18: ans=2.718281828;
                     tv.setText(Double.toString(ans)); break;
            //for cube root
            case 19: x=Double.parseDouble(tv.getText().toString());
                     ans=Math.cbrt(x);
                     tv.setText(Double.toString(ans)); break;
            //for cube
            case 20: x = Double.parseDouble(tv.getText().toString());
                     ans=Math.pow(x, 3);
                     tv.setText(Double.toString(ans)); break;
        }
        split();
        num1=ans; clear=0; oprCount=0; pointCount=0; start=true;
    }

    private void fact() {
        Double x;
        ans=1;
        x=Double.parseDouble(tv.getText().toString());
        if(x>=0 && x==Math.floor(x))
        {
            for(int i=1;i<=x;i++)
            {
                ans*=i;
            }
            tv.setText(Double.toString(ans));
            split();
        }
        else
            Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
        num1=ans; clear=0; oprCount=0; pointCount=0; start=true;
    }
    //for mod
    private void mod() {
        ans=Double.parseDouble(tv.getText().toString());
        powerValue=3;
        num1=ans; clear=0; oprCount=0; pointCount=0; start=true;
    }


    //for +/-
    private void change() {
        String strnew="";
        scr=tv.getText().toString();
        if(scr.charAt(0)=='-')
        {
            for(int i=1;i<scr.length();i++)
                strnew+=scr.charAt(i);
                tv.setText(strnew);
                split();
        }
        else
        {
            scr="-"+scr;
            tv.setText(scr);
            split();
        }
        clear+=1;
    }

    //for delete button
    private void delete() {
        String strnew="",str;
        char lastchar;
        try
        {
            str=tv.getText().toString();
            int l=str.length();
            lastchar=str.charAt(l - 1);
            if(lastchar=='.') pointCount=0;
            for(int i=0;i<l-1;i++)
                strnew+=str.charAt(i);
            tv.setText(strnew);
            split();
        }catch (Exception e)
        {
            ac();
        }
    }

    //for point
    private void point() {
        if(clear==0) { tv.setText("0"); tvmain.setText("0"); }
        scr=tv.getText().toString();
        if(pointCount==0) scr+=".";
        else Toast.makeText(this,"INVALID... There is already a point",Toast.LENGTH_LONG).show();
        tv.setText(scr);
        split();
        clear+=1; pointCount+=1;
    }

    //for AC
    private void ac() {
        tv.setText("0");
        tvopr.setText("");
        tvmain.setText("0");
        tvpower.setText("");
        tvpower10.setText("");
        num1=0;
        num2=0;
        ans=0;
        start=true;
        clear=0;
        oprCount=0;
        pointCount=0;
        powerValue=0;
    }

    //for Equal
    private void equal() {
        tvopr.setText("=");
        num2 = Double.parseDouble(tv.getText().toString());
        if(powerValue==0)
        {
            if(opr=="+") ans=num1+num2;
            if(opr=="-") ans=num1-num2;
            if(opr=="*") ans=num1*num2;
            if(opr=="/") ans=num1/num2;
        }
        if(powerValue==1) ans=Math.pow(num1,1/num2);
        if(powerValue==2) ans=Math.pow(num1,num2);
        if(powerValue==3) ans=num1%num2;
        tv.setText(Double.toString(ans)); //when pres equal then print ans
        split();
        num1=ans;
        clear=0; oprCount=0; pointCount=0; powerValue=0;
        start=true;
    }

    //for option button
    //here oprprev store prev opr when opr select more then one time, present opr is opr
    //oprcount count how many time opr select
    //if oprcount!=0 then store two value...
    //start is use for when opr select two time, let enter 1 no. then select opr. enter 2 no. if again select opr then
    //it tell that to cal the ans and print
    private void operation(String s) {

        tvopr.setText(s);
        if(oprCount==0) opr=s;
        else { oprPrev=opr; opr=s; }
        if(start==true)
        {
            num1=Double.parseDouble(tv.getText().toString());
            start=false;
            //if opr select 1 time then string number store in num1
        }
        else
        {
            num2 = Double.parseDouble(tv.getText().toString());
            if(oprPrev=="+") ans=num1+num2;
            if(oprPrev=="-") ans=num1-num2;
            if(oprPrev=="*") ans=num1*num2;
            if(oprPrev=="/") ans=num1/num2;
            tv.setText(Double.toString(ans));
            split();
            num1=ans;
            clear=0;
        }
        clear=0; pointCount=0;
        oprCount+=1;
    }
    //for keyboard press
    //clear is for chek whether our screen must b clear or not
    //if clear ==0 then clear
    //tv is my practice screen and tv main is main screen. we calculate whole thing whith
    //help of tv and split into 2 part nd show in tvmain
    private void number(String n) {
        if(clear==0) { tv.setText(""); tvopr.setText(""); tvmain.setText(""); tvpower.setText(""); tvpower10.setText("");}
        scr=tv.getText().toString();
        scr=scr+n;
        tv.setText(scr);
        split();
        clear+=1;
    }

    //splite screen
    private void split()
    {
        String str,decimal,power;
        str=tv.getText().toString();
        int position=str.indexOf('E');
        if(position==-1)
        {
            tvmain.setText(str);
        }
        else
        {
            decimal=str.substring(0,position);
            power=str.substring(position+1);
            tvmain.setText(decimal);
            tvpower.setText(power);
            tvpower10.setText("* 10");
        }
    }

    private void degreefunc() {
        if(degree==true)
        {
            btdeg.setText("radian");
            btdeg.setGravity(Gravity.BOTTOM|Gravity.RIGHT);
            degree=false;
        }
        else
        {
            btdeg.setText("degree");
            btdeg.setGravity(Gravity.BOTTOM | Gravity.CENTER);
            degree=true;
        }
    }
}
