package com.example.nfraz007.tictactoe;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by nfraz007 on 24-06-2015.
 */
public class MainGameSingle extends Activity implements View.OnClickListener {

    public Button bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9;
    Button bt[] = {bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9};
    TextView tv1;
    int arr[] = {0, 0, 0, 0, 0, 0, 0, 0, 0}, win = -1, sign;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maingame);
        init();
        tv1.setText(R.string.yturn);
        count=0;
    }

    private void init() {
        bt[0] = (Button) findViewById(R.id.xbt1);
        bt[1] = (Button) findViewById(R.id.xbt2);
        bt[2] = (Button) findViewById(R.id.xbt3);
        bt[3] = (Button) findViewById(R.id.xbt4);
        bt[4] = (Button) findViewById(R.id.xbt5);
        bt[5] = (Button) findViewById(R.id.xbt6);
        bt[6] = (Button) findViewById(R.id.xbt7);
        bt[7] = (Button) findViewById(R.id.xbt8);
        bt[8] = (Button) findViewById(R.id.xbt9);

        tv1 = (TextView) findViewById(R.id.xtv1);

        bt[0].setOnClickListener(this);
        bt[1].setOnClickListener(this);
        bt[2].setOnClickListener(this);
        bt[3].setOnClickListener(this);
        bt[4].setOnClickListener(this);
        bt[5].setOnClickListener(this);
        bt[6].setOnClickListener(this);
        bt[7].setOnClickListener(this);
        bt[8].setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.xbt1:
                calculate(0);
                break;
            case R.id.xbt2:
                calculate(1);
                break;
            case R.id.xbt3:
                calculate(2);
                break;
            case R.id.xbt4:
                calculate(3);
                break;
            case R.id.xbt5:
                calculate(4);
                break;
            case R.id.xbt6:
                calculate(5);
                break;
            case R.id.xbt7:
                calculate(6);
                break;
            case R.id.xbt8:
                calculate(7);
                break;
            case R.id.xbt9:
                calculate(8);
                break;

        }

        //comp turn
        Random rand=new Random();
        for(int i=0;i<9;i++)
        {
            int x=rand.nextInt(9);
            if(arr[x]==0)
            {
                calculate(x);
                break;
            }
        }

        if(count==9)
        {
            Bundle winner=new Bundle();
            winner.putString("name","Match Draw");
            winner.putInt("mode", 1);
            Intent a=new Intent(this,Result.class);
            a.putExtras(winner);
            startActivity(a);
        }
        if(win==1)
        {
            Bundle winner=new Bundle();
            winner.putString("name","You WIN");
            winner.putInt("mode",1);
            Intent a=new Intent(this,Result.class);
            a.putExtras(winner);
            startActivity(a);
        }
        if(win==2)
        {
            Bundle winner=new Bundle();
            winner.putString("name","You LOOSE");
            winner.putInt("mode",1);
            Intent a=new Intent(this,Result.class);
            a.putExtras(winner);
            startActivity(a);
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void calculate(int id) {

        if (arr[id] == 0) {
            //for computer
            if (count % 2 == 0) {
                bt[id].setBackground(getResources().getDrawable(R.drawable.button2));
                //bt[id].setBackgroundColor(Color.WHITE);
                bt[id].setTextColor(Color.BLACK);
                bt[id].setTextSize(40);
                tv1.setText(R.string.yturn);
                bt[id].setText("X");
                arr[id] = 1;
            }
            //for player
            if (count % 2 == 1) {
                bt[id].setBackground(getResources().getDrawable(R.drawable.button1));
                //bt[id].setBackgroundColor(Color.BLACK);
                bt[id].setTextColor(Color.WHITE);
                bt[id].setTextSize(40);
                tv1.setText(R.string.comturn);
                bt[id].setText("O");
                arr[id] = 2;
            }
            count++;
        } else {
            Toast t = Toast.makeText(MainGameSingle.this, "Already fillup", Toast.LENGTH_LONG);
            t.show();
        }
        //chek whether there are any winner
        //row 1
        if (arr[0] == 1 && arr[1] == 1 && arr[2] == 1) win = 1;
        if (arr[0] == 2 && arr[1] == 2 && arr[2] == 2) win = 2;

        //row 2
        if (arr[3] == 1 && arr[4] == 1 && arr[5] == 1) win = 1;
        if (arr[3] == 2 && arr[4] == 2 && arr[5] == 2) win = 2;

        //row 3
        if (arr[6] == 1 && arr[7] == 1 && arr[8] == 1) win = 1;
        if (arr[6] == 2 && arr[7] == 2 && arr[8] == 2) win = 2;

        //col 1
        if (arr[0] == 1 && arr[3] == 1 && arr[6] == 1) win = 1;
        if (arr[0] == 2 && arr[3] == 2 && arr[6] == 2) win = 2;

        //col 2
        if (arr[1] == 1 && arr[4] == 1 && arr[7] == 1) win = 1;
        if (arr[1] == 2 && arr[4] == 2 && arr[7] == 2) win = 2;

        //col 3
        if (arr[2] == 1 && arr[5] == 1 && arr[8] == 1) win = 1;
        if (arr[2] == 2 && arr[5] == 2 && arr[8] == 2) win = 2;

        //diog 1
        if (arr[0] == 1 && arr[4] == 1 && arr[8] == 1) win = 1;
        if (arr[0] == 2 && arr[4] == 2 && arr[8] == 2) win = 2;

        //diog 2
        if (arr[2] == 1 && arr[4] == 1 && arr[6] == 1) win = 1;
        if (arr[2] == 2 && arr[4] == 2 && arr[6] == 2) win = 2;
    }
}