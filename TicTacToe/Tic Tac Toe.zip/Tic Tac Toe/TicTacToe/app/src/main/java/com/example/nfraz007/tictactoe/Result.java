package com.example.nfraz007.tictactoe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by nfraz007 on 25-06-2015.
 */
public class Result extends Activity implements View.OnClickListener {

    Button btretry,btmenu;
    TextView tvres;
    int mode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);
        init();

        Bundle basket=getIntent().getExtras();
        String name =basket.getString("name");
        mode=basket.getInt("mode");
        tvres.setText(name);
        tvres.setTextSize(20);
        tvres.setTextColor(Color.WHITE);
    }

    private void init() {
        btretry=(Button)findViewById(R.id.xbtretry);
        btmenu=(Button)findViewById(R.id.xbtmenu);
        tvres=(TextView)findViewById(R.id.xtvres);
        btretry.setOnClickListener(this);
        btmenu.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.xbtmenu:
                startActivity(new Intent("com.example.nfraz007.tictactoe.StartScreen"));
                break;

            case R.id.xbtretry:
                if(mode==1) startActivity(new Intent(this,MainGameSingle.class));
                if(mode==2) startActivity(new Intent(this,MainGame.class));
                break;
        }
    }
}
