package com.example.nfraz007.tictactoe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Created by nfraz007 on 25-06-2015.
 */
public class Start extends Activity {
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);
        Thread timer=new Thread()
        {
            public void run()
            {
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    startActivity(new Intent("com.example.nfraz007.tictactoe.StartScreen"));
                }
            }
        };
        timer.start();
    }
}
