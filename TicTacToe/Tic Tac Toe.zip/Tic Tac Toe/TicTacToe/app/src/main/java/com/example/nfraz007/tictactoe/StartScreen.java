package com.example.nfraz007.tictactoe;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

/**
 * Created by nfraz007 on 24-06-2015.
 */
public class StartScreen extends Activity implements View.OnClickListener {
    Button btsingle,btmultiplayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.startscreen);
        btsingle=(Button)findViewById(R.id.xbtsingle);
        btmultiplayer=(Button)findViewById(R.id.xbtmultiplayer);
        btsingle.setOnClickListener(this);
        btmultiplayer.setOnClickListener(this);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            case R.id.xbtsingle:
                btsingle.setBackground(getResources().getDrawable(R.drawable.button1));
                startActivity(new Intent("com.example.nfraz007.tictactoe.MainGameSingle"));
                break;
            case R.id.xbtmultiplayer:
                btmultiplayer.setBackground(getResources().getDrawable(R.drawable.button1));
                startActivity(new Intent("com.example.nfraz007.tictactoe.MainGame"));
                break;
        }

    }
}
